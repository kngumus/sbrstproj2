package com.trvlmngmnt11.bsassign.controller;

import com.trvlmngmnt11.bsassign.dto.PassengerDto;
// import com.trvlmngmnt11.bsassign.model.Passenger;
// ^^(BU UNUSED OLDUĞU İÇİN UYARI VERDİ, SİLİNMELİ SANIRIM (37.17))
import com.trvlmngmnt11.bsassign.service.PassengerService;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api/passengers")
public class PassengerController {

    private PassengerService passengerService;


    //Build Add Passenger REST API
    @PostMapping
    public ResponseEntity<PassengerDto> createPassenger(@RequestBody PassengerDto passengerDto) {
        PassengerDto savedPassenger = passengerService.createPassenger(passengerDto);
        return new ResponseEntity<>(savedPassenger, HttpStatus.CREATED);
    }

    //Build Get Passenger REST API
    @GetMapping("{id}")
    public ResponseEntity<PassengerDto> getPassengerById(@PathVariable("id") Long passengerId) {
        PassengerDto passengerDto = passengerService.getPassengerById(passengerId);
        return ResponseEntity.ok(passengerDto);
    }

    //Build Get All Passengers REST API
    @GetMapping
    public ResponseEntity<List<PassengerDto>> getAllPassengers() {
        List<PassengerDto> passengers = passengerService.getAllPassengers();
        return ResponseEntity.ok(passengers);
    }

    //Build Update Passenger REST API
    @PutMapping("{id}")
    public ResponseEntity<PassengerDto> updatePassenger(@PathVariable("id") Long passengerId,
                                                        @RequestBody PassengerDto updatedPassenger) {
        PassengerDto passengerDto = passengerService.updatePassenger(passengerId, updatedPassenger);
        return ResponseEntity.ok(passengerDto);
    }

    //Build Delete Passenger REST API
    @DeleteMapping("{id}")
    public ResponseEntity<String> deletePassenger(@PathVariable("id") Long passengerId) {
        passengerService.deletePassenger(passengerId);
        return ResponseEntity.ok("Passenger deleted successfully");
    }
}
