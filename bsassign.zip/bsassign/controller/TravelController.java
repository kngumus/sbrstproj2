package com.trvlmngmnt11.bsassign.controller;

import com.trvlmngmnt11.bsassign.dto.TravelDto;
import com.trvlmngmnt11.bsassign.exception.ResourceNotFoundException;
import com.trvlmngmnt11.bsassign.repository.TravelRepository;
import com.trvlmngmnt11.bsassign.service.BusService;
import com.trvlmngmnt11.bsassign.service.PassengerService;
import com.trvlmngmnt11.bsassign.service.TravelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/travels")
public class TravelController {

    private static final Logger LOGGER = LoggerFactory.getLogger(TravelController.class);
    private final TravelService travelService;
    private final PassengerService passengerService;
    private final BusService busService;
    private final TravelRepository travelRepository;


    public TravelController(TravelService travelService, PassengerService passengerService, BusService busService, TravelRepository travelRepository) {
        this.travelService = travelService;
        this.passengerService = passengerService;
        this.busService = busService;
        this.travelRepository = travelRepository;
    }


    //Build Add Travel REST API
    @PostMapping(value = "/add", consumes = "application/json", produces = "application/json")
    public ResponseEntity<TravelDto> createTravel(@RequestBody TravelDto travelDto) {
        LOGGER.info("Create Travel {}", travelDto);
        return new ResponseEntity<>(travelService.createTravel(travelDto), HttpStatus.CREATED);
//        LOGGER.info("Create Travel {}", travelDto);
//        return new ResponseEntity<>(travelService.createTravel(travelDto), HttpStatus.CREATED);
    }

    //Build Get Travel REST API
    @GetMapping(value = "/get/{id}", produces = "application/json")
    public ResponseEntity<TravelDto> getTravel(@PathVariable Long id) {
        if (id <= 0) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        TravelDto travelDto = travelService.getTravelById(id);
        if (travelDto == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(travelDto, HttpStatus.OK);
    }

    //Build Get All Travels REST API
    @GetMapping(value = "/all", produces = "application/json")
    public ResponseEntity<List<TravelDto>> getAllTravels() {
        List<TravelDto> travels = travelService.getAllTravels();
        if (travels.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // Return 204 if no travels are found
        }
        return ResponseEntity.ok(travels);
    }

    //Build Update Travel REST API
    @PutMapping("/update/{id}")
    public ResponseEntity<TravelDto> updateTravel(@PathVariable Long id, @RequestBody TravelDto travelDto) {
        if (id <= 0 || travelDto == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        TravelDto updatedTravel = travelService.updateTravel(id, travelDto);
        if (updatedTravel == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // Return 404 if the travel was not found
        }

        return new ResponseEntity<>(updatedTravel, HttpStatus.OK);
    }


    //Build Delete Travel REST API
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTravel(@PathVariable Long id) {
//        if (id <= 0) {
//            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//        }

        travelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("This travel does not exist" + ": " + id));

        travelService.deleteTravel(id);
        return ResponseEntity.ok("Travel deleted successfully!");
    }

}

//Travel deleted successfully!













