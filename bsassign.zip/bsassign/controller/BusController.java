package com.trvlmngmnt11.bsassign.controller;

import com.trvlmngmnt11.bsassign.dto.BusDto;
import com.trvlmngmnt11.bsassign.service.BusService;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api/buses")
public class BusController {

    private BusService busService;

    // Build Add Bus REST API
    @PostMapping
    public ResponseEntity<BusDto> createBus(@RequestBody BusDto busDto) {
        BusDto savedBus = busService.createBus(busDto);
        return new ResponseEntity<>(savedBus, HttpStatus.CREATED);
    }


    //Build Get Bus REST API
    @GetMapping("{id}")
    public ResponseEntity<BusDto> getBusById(@PathVariable("id") Long busId) {
        BusDto busDto = busService.getBusById(busId);
        return ResponseEntity.ok(busDto);
    }


    //Build Get All Bus REST API
    @GetMapping
    public ResponseEntity<List<BusDto>> getAllBuses() {
        List<BusDto> buses = busService.getAllBuses();
        if (buses.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return ResponseEntity.ok(buses);
    }

    //Build Update Bus REST API
    @PutMapping("{id}")
    public ResponseEntity<BusDto> updateBus(@PathVariable("id") Long busId ,@RequestBody BusDto updatedBus) {
        BusDto busDto = busService.updateBus(busId, updatedBus);
        if (busDto == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(busDto);
    }

    //Build Delete Bus REST API
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteBus(@PathVariable("id") Long busId) {
        busService.deleteBus(busId);
        return ResponseEntity.ok("Bus deleted successfully!");
    }

}
