package com.trvlmngmnt11.bsassign.controller;

import com.trvlmngmnt11.bsassign.model.User;
import com.trvlmngmnt11.bsassign.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Controller
@RequestMapping("/user")
public class UserController {
    private final UserRepository userRepository;
    public UserController(UserRepository userRepository){this.userRepository = userRepository;}

    //Get all users
    @GetMapping("/all")
    public String allUsers(Model model){
        model.addAttribute("users",userRepository.findAll());
        return "user/all";
    }

    //Get user
    @GetMapping("/{id}")
    public String getUser(Model model){
        model.addAttribute("user", new User());
        return "user/_show";
    }

    //Add user
    @PostMapping("/add")
    public String addUser(@ModelAttribute("user") User user, @RequestParam("img") MultipartFile file){
        String fileName = file.getOriginalFilename();
        if(fileName.isEmpty() && user.getImageUrl().isEmpty()){
            user.setImageUrl("noimage.png");
        } else if (!fileName.isEmpty()) {
            //File upload
            user.setImageUrl(file.getOriginalFilename()); //parantez içi sadece fileName olarak dene hata verirse
            String uploadDir = "src/main/resources/static/images/" + fileName;
            Path uploadPath = Paths.get(uploadDir);
            try {
                Files.copy(file.getInputStream(), uploadPath, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                System.out.println("An error has occured while saving the file!" + ex);
            }
        }
        userRepository.save(user);
        return "redirect:/user/all";
    }

    //Update user
    @GetMapping("/update/{id}")
    public String updateUser(@PathVariable Long id, Model model){
        model.addAttribute("user",userRepository.findById(id).orElse(null));
        return "user/_update";
    }

    @PostMapping("/update")
    public String updateUser(@ModelAttribute("user") User user, @RequestParam("img") MultipartFile file){
        Long id = user.getId();
        if(id == null || id<=0)
            throw new IllegalArgumentException("Invalid user ID");

        String fileName = file.getOriginalFilename();
        if(fileName.isEmpty() && user.getImageUrl().isEmpty()){
            user.setImageUrl("noimage.png");
        } else if (!fileName.isEmpty()) {
            user.setImageUrl(file.getOriginalFilename()); //sadece fileName de olabilir
            String uploadDir = "src/main/resources/static/images/" + fileName;
            Path uploadPath = Paths.get(uploadDir);
            try {
                Files.copy(file.getInputStream(), uploadPath, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                System.out.println("An error has occured while saving the file!" + ex);
            }
        }

        User u = userRepository.findById(id).get();
        u.setEmail(user.getEmail());
        u.setUsername(user.getUsername());
        u.setPassword(user.getPassword());
        u.setRole(user.getRole());
        u.setImageUrl(user.getImageUrl());
        userRepository.save(u);
        return "redirect:/user/all";
    }

    //Delete user

    public ResponseEntity userDelete(@PathVariable Long id){
        if(id == null || id<=0)
            throw new IllegalArgumentException("Invalid user ID");
        //Image deletion
        User user = userRepository.findById(id).get();
        if(!user.getImageUrl().isEmpty()){
            String fileName = user.getImageUrl();
            File file = new File("src/main/resources/static/images/" + fileName);
            try{
                boolean result = Files.deleteIfExists(file.toPath());
            } catch(IOException e){
                e.printStackTrace();
            }
        }
        userRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }



































}
