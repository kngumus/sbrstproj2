package com.trvlmngmnt11.bsassign.service;

import com.trvlmngmnt11.bsassign.dto.BusDto;

import java.util.List;

public interface BusService {

    BusDto createBus(BusDto busDto);

    BusDto getBusById(Long busId);

    List<BusDto> getAllBuses();

    BusDto updateBus(Long busId, BusDto updatedBus);

    void deleteBus(Long busId);
}
