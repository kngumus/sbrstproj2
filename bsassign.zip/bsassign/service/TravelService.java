package com.trvlmngmnt11.bsassign.service;

import com.trvlmngmnt11.bsassign.dto.TravelDto;

import java.util.List;

public interface TravelService {
    TravelDto createTravel(TravelDto travelDto);

    TravelDto getTravelById(Long travelId);

    List<TravelDto> getAllTravels();

    TravelDto updateTravel(Long travelId, TravelDto travelDto);

    void deleteTravel(Long travelId);
}
