package com.trvlmngmnt11.bsassign.service.impl;

import com.trvlmngmnt11.bsassign.dto.PassengerDto;
import com.trvlmngmnt11.bsassign.model.Passenger;
import com.trvlmngmnt11.bsassign.exception.ResourceNotFoundException;
import com.trvlmngmnt11.bsassign.mapper.PassengerMapper;
import com.trvlmngmnt11.bsassign.repository.PassengerRepository;
import com.trvlmngmnt11.bsassign.service.PassengerService;
import com.trvlmngmnt11.bsassign.service.TravelService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
@AllArgsConstructor
public class PassengerServiceImpl implements PassengerService {

    private final TravelService travelService;
    private PassengerRepository passengerRepository;


    @Override
    public PassengerDto createPassenger(PassengerDto passengerDto) {

        Passenger passenger = PassengerMapper.mapToPassenger(passengerDto);
        Passenger savedPassenger = passengerRepository.save(passenger);
        return PassengerMapper.mapToPassengerDto(savedPassenger);


//        Passenger passenger = PassengerMapper.mapToPassenger(passengerDto);
//        Passenger savedPassenger = passengerRepository.save(passenger);
//        return PassengerMapper.mapToPassengerDto(savedPassenger);
    }

    @Override
    public PassengerDto getPassengerById(Long passengerId) {
        Passenger passenger = passengerRepository.findById(passengerId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Passenger with id: " + passengerId + " not found"));
        return PassengerMapper.mapToPassengerDto(passenger);

    }

    @Override
    public List<PassengerDto> getAllPassengers() {
        List<Passenger> passengers = passengerRepository.findAll();
        return passengers.stream().map((passenger) -> PassengerMapper.mapToPassengerDto(passenger))
                .collect(Collectors.toList());
    }

    @Override
    public PassengerDto updatePassenger(Long passengerId, PassengerDto updatedPassenger) {
        Passenger passenger = passengerRepository.findById(passengerId).orElseThrow(
                () -> new ResourceNotFoundException("Passenger with id: " + passengerId + " not found")
        );

        passenger.setFirstName(updatedPassenger.getFirstName());
        passenger.setLastName(updatedPassenger.getLastName());
        passenger.setPhone(updatedPassenger.getPhone());
        passenger.setAddress(updatedPassenger.getAddress());

        Passenger updatedPassengerObj = passengerRepository.save(passenger);

        return PassengerMapper.mapToPassengerDto(updatedPassengerObj);
    }

    @Override
    public void deletePassenger(Long passengerId) {
        Passenger passenger = passengerRepository.findById(passengerId).orElseThrow(
                () -> new ResourceNotFoundException("Passenger with id: " + passengerId + " not found")
        );
        passengerRepository.deleteById(passengerId);
    }
}
