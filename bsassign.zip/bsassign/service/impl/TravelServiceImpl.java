package com.trvlmngmnt11.bsassign.service.impl;

import com.trvlmngmnt11.bsassign.dto.TravelDto;
import com.trvlmngmnt11.bsassign.model.Travel;
import com.trvlmngmnt11.bsassign.exception.ResourceNotFoundException;
import com.trvlmngmnt11.bsassign.mapper.TravelMapper;
import com.trvlmngmnt11.bsassign.repository.BusRepository;
import com.trvlmngmnt11.bsassign.repository.PassengerRepository;
import com.trvlmngmnt11.bsassign.repository.TravelRepository;
import com.trvlmngmnt11.bsassign.service.TravelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TravelServiceImpl implements TravelService {

    @Autowired
    private TravelRepository travelRepository;
    @Autowired
    private BusRepository busRepository;
    @Autowired
    private PassengerRepository passengerRepository;

    @Transactional
    @Override
    public TravelDto createTravel(TravelDto travelDto) {
        // First, you need to ensure the passenger and bus exist
        //Passenger passenger = passengerService.getPassengerById(travelDto.getPassenger().getId());
        //Bus bus = busService.getBusById(travelDto.getBus().getId());

        // Map the TravelDto to Travel entity
        Travel travel = TravelMapper.mapToTravel(travelDto);

        // Set the passenger and bus objects into the travel entity
        //travel.setPassenger(passenger);
        //travel.setBus(bus);

        // Save the travel entity to the database
        Travel savedTravel = travelRepository.save(travel);

        // Map the saved Travel entity back to TravelDto
        return TravelMapper.mapToTravelDto(savedTravel);
    }

    @Transactional
    @Override
    public TravelDto getTravelById(Long travelId) {
        Travel travel = travelRepository.findById(travelId).orElseThrow(() -> new ResourceNotFoundException("Travel not found" + ":" + travelId));
        return TravelMapper.mapToTravelDto(travel);
    }

    @Override
    public List<TravelDto> getAllTravels() {
        return travelRepository.findAll().stream()
                .map(TravelMapper::mapToTravelDto) // Assuming a TravelMapper to map entities to DTOs
                .collect(Collectors.toList());
    }

    @Transactional
    @Override
    public TravelDto updateTravel(Long travelId, TravelDto updatedTravel) {
        Travel travel = travelRepository.findById(travelId).orElseThrow(() -> new ResourceNotFoundException("Travel not found" + ":" + travelId));
        travel.setDate(updatedTravel.getDate());
        travel.setTime(updatedTravel.getTime());
        travel.setPrice(updatedTravel.getPrice());
        travel.setSeat(updatedTravel.getSeat());

        Travel updatedTravelObj = travelRepository.save(travel);
        return TravelMapper.mapToTravelDto(updatedTravelObj);
    }

    @Transactional
    @Override
    public void deleteTravel(Long travelId) {
        Travel travel = travelRepository.findById(travelId)
                .orElseThrow(() -> new ResourceNotFoundException("Travel not found"));
        travelRepository.deleteById(travelId);
    }
}


