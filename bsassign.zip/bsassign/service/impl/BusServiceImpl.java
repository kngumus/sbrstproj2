package com.trvlmngmnt11.bsassign.service.impl;

import com.trvlmngmnt11.bsassign.dto.BusDto;
import com.trvlmngmnt11.bsassign.model.Bus;
import com.trvlmngmnt11.bsassign.exception.ResourceNotFoundException;
import com.trvlmngmnt11.bsassign.mapper.BusMapper;
import com.trvlmngmnt11.bsassign.repository.BusRepository;
import com.trvlmngmnt11.bsassign.service.BusService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class BusServiceImpl implements BusService {
    private final BusRepository busRepository;

    @Override
    public BusDto createBus(BusDto busDto) {
        Bus bus = new Bus(
                busDto.getId(),
                busDto.getAgency(),
                busDto.getOrigin(),
                busDto.getDestination()
        );
        Bus savedBus = busRepository.save(bus);

        return new BusDto(
                savedBus.getId(),
                savedBus.getAgency(),
                savedBus.getOrigin(),
                savedBus.getDestination()
        );
    }

    @Override
    public BusDto getBusById(Long busId) {
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new ResourceNotFoundException("Bus with id: " + busId + " not found"));

        // Convert Bus entity to BusDto
        return new BusDto(
                bus.getId(),
                bus.getAgency(),
                bus.getOrigin(),
                bus.getDestination()
        );
    }

    @Override
    public List<BusDto> getAllBuses() {
        List<Bus> buses = busRepository.findAll();

        // Convert List<Bus> to List<BusDto>
        return buses.stream().map((bus) -> BusMapper.mapToBusDto(bus))
                .collect(Collectors.toList());
    }

    @Override
    public BusDto updateBus(Long busId, BusDto updatedBus) {
        // Retrieve the existing Bus entity by ID
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new ResourceNotFoundException("Bus with id: " + busId + " not found"));

        // Update the existing Bus entity with new values from the updatedBusDto
        bus.setAgency(updatedBus.getAgency());
        bus.setOrigin(updatedBus.getOrigin());
        bus.setDestination(updatedBus.getDestination());

        // Save the updated Bus entity
        Bus updatedBusObj = busRepository.save(bus);

        // Convert the updated Bus entity to BusDto and return
        return BusMapper.mapToBusDto(updatedBusObj);
    }

    @Override
    public void deleteBus(Long busId) {
        Bus bus = busRepository.findById(busId).orElseThrow(() -> new ResourceNotFoundException("Bus with id: " + busId + " not found"));
        busRepository.deleteById(busId);
    }
}