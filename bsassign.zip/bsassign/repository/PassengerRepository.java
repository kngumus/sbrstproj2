package com.trvlmngmnt11.bsassign.repository;

import com.trvlmngmnt11.bsassign.model.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PassengerRepository extends JpaRepository<Passenger, Long> {
}
