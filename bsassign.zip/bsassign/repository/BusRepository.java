package com.trvlmngmnt11.bsassign.repository;

import com.trvlmngmnt11.bsassign.model.Bus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus, Long> {
}
