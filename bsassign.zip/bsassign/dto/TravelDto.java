package com.trvlmngmnt11.bsassign.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TravelDto {
     private Long id;
     private LocalDate date;
     private LocalTime time;
     private Double price;
     private String seat;
     private PassengerDto passengerDto;
     private BusDto busDto;
}
