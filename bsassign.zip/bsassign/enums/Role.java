package com.trvlmngmnt11.bsassign.enums;

public enum Role {
    USER, ADMIN
}
