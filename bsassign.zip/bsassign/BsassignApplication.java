package com.trvlmngmnt11.bsassign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BsassignApplication {

	public static void main(String[] args) {
		SpringApplication.run(BsassignApplication.class, args);
	}

}
