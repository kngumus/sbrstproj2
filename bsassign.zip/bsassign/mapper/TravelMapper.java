package com.trvlmngmnt11.bsassign.mapper;

import com.trvlmngmnt11.bsassign.dto.TravelDto;
import com.trvlmngmnt11.bsassign.model.Bus;
import com.trvlmngmnt11.bsassign.model.Passenger;
import com.trvlmngmnt11.bsassign.model.Travel;

public class TravelMapper {
    public static TravelDto mapToTravelDto(Travel travel) {
        return new TravelDto(
                travel.getId(),
                travel.getDate(),
                travel.getTime(),
                travel.getPrice(),
                travel.getSeat(),
                travel.getPassenger() != null ? PassengerMapper.mapToPassengerDto(travel.getPassenger()) : null,  // Map Passenger to PassengerDto
                travel.getBus() != null ? BusMapper.mapToBusDto(travel.getBus()) : null  // Map Bus to BusDto
//                new PassengerDto(
//                        travel.getPassenger().getId(),
//                        travel.getPassenger().getFirstName(),
//                        travel.getPassenger().getLastName(),
//                        travel.getPassenger().getPhone(),
//                        travel.getPassenger().getAddress()
//                ),
//                new BusDto(
//                        travel.getBus().getId(),
//                        travel.getBus().getAgency(),
//                        travel.getBus().getOrigin(),
//                        travel.getBus().getDestination()
//                )
        );
    }

    // Maps TravelDto to Travel entity
    public static Travel mapToTravel(TravelDto travelDto) {
        return new Travel(
                travelDto.getId(),
                travelDto.getDate(),
                travelDto.getTime(),
                travelDto.getPrice(),
                travelDto.getSeat(),
//                travelDto.getPassengerDto() != null ? PassengerMapper.mapToPassenger(travelDto.getPassengerDto()) : null,  // Map PassengerDto to Passenger
//                travelDto.getBusDto() != null ? BusMapper.mapToBus(travelDto.getBusDto()) : null  // Map BusDto to Bus
                new Passenger(
                        travelDto.getPassengerDto().getId(),
                        travelDto.getPassengerDto().getFirstName(),
                        travelDto.getPassengerDto().getLastName(),
                        travelDto.getPassengerDto().getPhone(),
                        travelDto.getPassengerDto().getAddress()
                ),
                new Bus(
                        travelDto.getBusDto().getId(),
                        travelDto.getBusDto().getAgency(),
                        travelDto.getBusDto().getOrigin(),
                        travelDto.getBusDto().getDestination()
                )
        );
    }
}
