package com.trvlmngmnt11.bsassign.mapper;

import com.trvlmngmnt11.bsassign.dto.PassengerDto;
import com.trvlmngmnt11.bsassign.model.Passenger;

/* Mapper class maps passenger entity to passenger dto and vice versa */

public class PassengerMapper {

    public static PassengerDto mapToPassengerDto(Passenger passenger) {
        return new PassengerDto(
                passenger.getId(),
                passenger.getFirstName(),
                passenger.getLastName(),
                passenger.getPhone(),
                passenger.getAddress()
        );
    }
    public static Passenger mapToPassenger(PassengerDto passengerDto) {
        return new Passenger(
                passengerDto.getId(),
                passengerDto.getFirstName(),
                passengerDto.getLastName(),
                passengerDto.getPhone(),
                passengerDto.getAddress()
        );
    }
}
