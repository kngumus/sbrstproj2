package com.trvlmngmnt11.bsassign.mapper;

import com.trvlmngmnt11.bsassign.dto.BusDto;
import com.trvlmngmnt11.bsassign.model.Bus;


/* Mapper class maps bus entity to bus dto and vice versa */
public class BusMapper {
    public static BusDto mapToBusDto(Bus bus) {
        return new BusDto(
                bus.getId(),
                bus.getAgency(),
                bus.getOrigin(),
                bus.getDestination()
        );
    }

    public static Bus mapToBus(BusDto busDto) {
        return new Bus(
                busDto.getId(),
                busDto.getAgency(),
                busDto.getOrigin(),
                busDto.getDestination()
        );
    }
}
