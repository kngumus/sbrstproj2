package com.trvlmngmnt11.bsassign.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "travels")
public class Travel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "date_local")
    private LocalDate date;

    @Column(name = "time_local")
    private LocalTime time;

    @Column(name = "price_tag")
    private Double price;

    @Column(name = "seat_id")
    private String seat;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "passenger_id")
    //@JsonBackReference
    private Passenger passenger;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bus_id")
    //@JsonBackReference
    private Bus bus;

    public Travel(){}


    // Constructor for Travel entity with required fields (id, date, time, price, seat)
    public Travel(Long id, LocalDate date, LocalTime time, Double price, String seat) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.price = price;
        this.seat = seat;
    }

    // Constructor for Travel entity with all fields (id, date, time, price, seat, passenger, bus)
    public Travel(Long id, LocalDate date, LocalTime time, Double price, String seat, Passenger passenger, Bus bus) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.price = price;
        this.seat = seat;
        this.passenger = passenger;
        this.bus = bus;
    }

    public Long getId(){return id;}

    public LocalDate getDate() {
        return date;
    }
    public LocalTime getTime() {
        return time;
    }
    public Double getPrice() {
        return price;
    }
    public String getSeat() {
        return seat;
    }
    public Passenger getPassenger() {
        return passenger;
    }
    public Bus getBus() {
        return bus;
    }

    public void setId(Long id) {this.id = id;}
    public void setDate(LocalDate date) {this.date = date;}
    public void setTime(LocalTime time) {this.time = time;}
    public void setPrice(Double price) {this.price = price;}
    public void setSeat(String seat) {this.seat = seat;}
    public void setPassenger(Passenger passenger) {this.passenger = passenger;}
    public void setBus(Bus bus) {this.bus = bus;}
}
