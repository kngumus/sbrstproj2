package com.trvlmngmnt11.bsassign.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name="buses")
public class Bus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "agency_id")
    private String agency;

    @Column(name = "origin_id")
    private String origin;

    @Column(name = "destination_id")
    private String destination;

    @OneToMany(mappedBy = "bus", cascade = CascadeType.ALL)
    //@JsonManagedReference
    private List<Travel> travels;

    public Bus() {}

    public Bus(Long id, String agency, String origin, String destination) {
        this.id = id;
        this.agency = agency;
        this.origin = origin;
        this.destination = destination;
    }

    public Long getId() {
        return id;
    }
    public String getAgency() {return agency;}
    public String getOrigin() {return origin;}
    public String getDestination() {return destination;}

    public void setId(Long id) {
        this.id = id;
    }
    public void setAgency(String agency) {this.agency = agency;}
    public void setOrigin(String origin) {this.origin = origin;}
    public void setDestination(String destination) {this.destination = destination;}
}
