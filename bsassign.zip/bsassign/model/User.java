package com.trvlmngmnt11.bsassign.model;

import com.trvlmngmnt11.bsassign.enums.Role;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users") //*
public class User { //@Table eklemeli miyiz?????
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "id") //**
    private Long id;

    @Column(name = "email") //**
    private String email;

    @Column(name = "username") //**
    private String username;

    @Column(name = "password") //**
    private String password;
    @Enumerated(EnumType.STRING)
    @Column(name = "roles") //**
    private Role role;
    @Column(name = "image") //**
    private String imageUrl = "noimage.png";
}
